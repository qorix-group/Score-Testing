use crate::{
    class1::{Class1, Class1Trait},
    test_tracker::TestTracker,
};
use mockall::automock;
use std::fmt;

#[derive(Clone)]
pub struct InstrumentedClass1 {
    inner: Class1,
    tracker: Option<TestTracker>,
}

#[automock]
pub trait InstrumentedClass1Trait {
    fn execute(&mut self, x: i32) -> i32;
    fn compute(&mut self, value: f64, count: i32) -> f64;
    fn get_counter(&self) -> i32;
}

impl InstrumentedClass1 {
    pub fn new(inner: Class1, tracker: Option<TestTracker>) -> Self {
        InstrumentedClass1 { inner, tracker }
    }
}

impl Class1Trait for InstrumentedClass1 {
    fn execute(&mut self, x: i32) -> i32 {
        if let Some(tracker) = self.tracker.as_mut() {
            tracker.push_call("Enter Class1::execute");
            if tracker.inject_fault("Class1::execute") {
                println!("Triggering fault injection for Class1::execute");
                tracker.push_call("FAULT INJECTED");
                panic!("Fault injected in Class1::execute");
            }
            tracker.insert_value("Class1::execute_input", x);
            let result = self.inner.execute(x);
            tracker.push_call("Exit Class1::execute");
            tracker.insert_value("Class1::execute_output", result);
            result
        } else {
            self.inner.execute(x)
        }
    }

    fn compute(&mut self, value: f64, count: i32) -> f64 {
        if let Some(tracker) = self.tracker.as_mut() {
            tracker.push_call("Enter Class1::compute");
            if tracker.inject_fault("Class1::compute") {
                println!("Triggering fault injection for Class1::compute");
                tracker.push_call("FAULT INJECTED");
                panic!("Fault injected in Class1::compute");
            }
            tracker.insert_value("Class1::compute_input", value);
            let result = self.inner.compute(value, count);
            tracker.push_call("Exit Class1::compute");
            tracker.insert_value("Class1::compute_output", result);
            result
        } else {
            self.inner.compute(value, count)
        }
    }

    fn get_counter(&self) -> i32 {
        if let Some(tracker) = self.tracker.as_ref() {
            let mut tracker = tracker.clone(); // Clone to allow mutation
            tracker.push_call("Enter Class1::get_counter");
            if tracker.inject_fault("Class1::get_counter") {
                println!("Triggering fault injection for Class1::get_counter");
                tracker.push_call("FAULT INJECTED");
                panic!("Fault injected in Class1::get_counter");
            }
            let result = self.inner.get_counter();
            tracker.push_call("Exit Class1::get_counter");
            tracker.insert_value("Class1::get_counter_output", result);
            result
        } else {
            self.inner.get_counter()
        }
    }
}

impl fmt::Debug for InstrumentedClass1 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("InstrumentedClass1")
            .field("inner", &self.inner)
            .field("tracker", &self.tracker)
            .finish()
    }
}

pub struct TestClass1 {
    c1: Class1,
    ic1: InstrumentedClass1,
}

impl TestClass1 {
    pub fn new(c1: Class1, ic1: InstrumentedClass1) -> Self {
        TestClass1 { c1, ic1 }
    }

    pub fn execute(&mut self, x: i32) -> i32 {
        self.c1.execute(x)
    }

    pub fn proxy_execute(&mut self, x: i32) -> i32 {
        self.ic1.execute(x)
    }

    pub fn compute(&mut self, value: f64, count: i32) -> f64 {
        self.c1.compute(value, count)
    }

    pub fn proxy_compute(&mut self, value: f64, count: i32) -> f64 {
        self.ic1.compute(value, count)
    }

    pub fn get_counter(&self) -> i32 {
        self.c1.get_counter()
    }

    pub fn proxy_get_counter(&self) -> i32 {
        self.ic1.get_counter()
    }
}