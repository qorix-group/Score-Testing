use crate::{
    class3::{Class3, Class3Trait},
    test_tracker::TestTracker,
};
use mockall::automock;
use std::fmt;

#[derive(Clone)]
pub struct InstrumentedClass3 {
    inner: Class3,
    tracker: Option<TestTracker>,
}

#[automock]
pub trait InstrumentedClass3Trait {
    fn process(&mut self, x: i32) -> i32;
    fn scale(&mut self, factor: f64, count: i32) -> f64;
    fn describe(&mut self) -> String;
}

impl InstrumentedClass3 {
    pub fn new(inner: Class3, tracker: Option<TestTracker>) -> Self {
        InstrumentedClass3 { inner, tracker }
    }
}

impl Class3Trait for InstrumentedClass3 {
    fn process(&mut self, x: i32) -> i32 {
        if let Some(tracker) = self.tracker.as_mut() {
            tracker.push_call("Enter Class3::process");
            if tracker.inject_fault("Class3::process") {
                println!("Triggering fault injection for Class3::process");
                tracker.push_call("FAULT INJECTED");
                panic!("Fault injected in Class3::process");
            }
            tracker.insert_value("Class3::process_input", x);
            let result = self.inner.process(x);
            tracker.push_call("Exit Class3::process");
            tracker.insert_value("Class3::process_output", result);
            result
        } else {
            self.inner.process(x)
        }
    }

    fn scale(&mut self, factor: f64, count: i32) -> f64 {
        if let Some(tracker) = self.tracker.as_mut() {
            tracker.push_call("Enter Class3::scale");
            if tracker.inject_fault("Class3::scale") {
                println!("Triggering fault injection for Class3::scale");
                tracker.push_call("FAULT INJECTED");
                panic!("Fault injected in Class3::scale");
            }
            tracker.insert_value("Class3::scale_input", factor);
            let result = self.inner.scale(factor, count);
            tracker.push_call("Exit Class3::scale");
            tracker.insert_value("Class3::scale_output", result);
            result
        } else {
            self.inner.scale(factor, count)
        }
    }

    fn describe(&mut self) -> String {
        if let Some(tracker) = self.tracker.as_mut() {
            tracker.push_call("Enter Class3::describe");
            if tracker.inject_fault("Class3::describe") {
                println!("Triggering fault injection for Class3::describe");
                tracker.push_call("FAULT INJECTED");
                panic!("Fault injected in Class3::describe");
            }
            let result = self.inner.describe();
            tracker.push_call("Exit Class3::describe");
            tracker.insert_value("Class3::describe_output", &result);
            result
        } else {
            self.inner.describe()
        }
    }
}

impl fmt::Debug for InstrumentedClass3 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("InstrumentedClass3")
            .field("inner", &self.inner)
            .field("tracker", &self.tracker)
            .finish()
    }
}

pub struct TestClass3 {
    c3: Class3,
    ic3: InstrumentedClass3,
}

impl TestClass3 {
    pub fn new(c3: Class3, ic3: InstrumentedClass3) -> Self {
        TestClass3 { c3, ic3 }
    }

    pub fn process(&mut self, x: i32) -> i32 {
        self.c3.process(x)
    }

    pub fn proxy_process(&mut self, x: i32) -> i32 {
        self.ic3.process(x)
    }

    pub fn scale(&mut self, factor: f64, count: i32) -> f64 {
        self.c3.scale(factor, count)
    }

    pub fn proxy_scale(&mut self, factor: f64, count: i32) -> f64 {
        self.ic3.scale(factor, count)
    }

    pub fn describe(&mut self) -> String {
        self.c3.describe()
    }

    pub fn proxy_describe(&mut self) -> String {
        self.ic3.describe()
    }
}