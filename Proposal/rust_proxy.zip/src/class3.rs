use std::fmt;

#[derive(Clone)]
pub struct Class3 {
    offset: i32,
    name: String,
}

pub trait Class3Trait: fmt::Debug {
    fn process(&mut self, x: i32) -> i32;
    fn scale(&mut self, factor: f64, count: i32) -> f64;
    fn describe(&mut self) -> String;
}

impl Class3 {
    pub fn new() -> Self {
        Class3 {
            offset: 5,
            name: "Class3".to_string(),
        }
    }
}

impl Class3Trait for Class3 {
    fn process(&mut self, x: i32) -> i32 {
        x.wrapping_mul(2).wrapping_add(self.offset) // Verwende wrapping arithmetic
    }

    fn scale(&mut self, factor: f64, count: i32) -> f64 {
        factor * count as f64 + self.offset as f64 // Additional method
    }

    fn describe(&mut self) -> String {
        format!("{}: Processing unit", self.name) // Uses attribute
    }
}

impl fmt::Debug for Class3 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Class3")
            .field("offset", &self.offset)
            .field("name", &self.name)
            .finish()
    }
}