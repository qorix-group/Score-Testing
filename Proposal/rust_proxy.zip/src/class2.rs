use crate::class3::{Class3, Class3Trait};
use std::fmt;

#[derive(Clone)]
pub struct Class2 {
    multiplier: i32,
    name: String,
}

pub trait Class2Trait: fmt::Debug {
    fn transform(&mut self, x: i32) -> i32;
    fn combine(&mut self, x: i32, label: &str) -> String;
    fn get_name(&mut self) -> String;
}

impl Class2 {
    pub fn new() -> Self {
        Class2 {
            multiplier: 2,
            name: "Class2".to_string(),
        }
    }
}

impl Class2Trait for Class2 {
    fn transform(&mut self, x: i32) -> i32 {
        let mut c3 = Class3::new();
        c3.process(x) * self.multiplier // Step 2: (x*2 + offset) * multiplier
    }

    fn combine(&mut self, x: i32, label: &str) -> String {
        let mut c3 = Class3::new();
        format!("{} | {} | {}", c3.describe(), label, x) // Combines attribute and input
    }

    fn get_name(&mut self) -> String {
        self.name.clone()
    }
}

impl fmt::Debug for Class2 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Class2")
            .field("multiplier", &self.multiplier)
            .field("name", &self.name)
            .finish()
    }
}