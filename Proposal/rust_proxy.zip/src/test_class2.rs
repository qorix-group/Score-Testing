use crate::{
    class2::{Class2, Class2Trait},
    test_tracker::TestTracker,
};
use mockall::automock;
use std::fmt;

#[derive(Clone)]
pub struct InstrumentedClass2 {
    inner: Class2,
    tracker: Option<TestTracker>,
}

#[automock]
pub trait InstrumentedClass2Trait {
    fn transform(&mut self, x: i32) -> i32;
    fn combine(&mut self, x: i32, label: &str) -> String;
    fn get_name(&mut self) -> String;
}

impl InstrumentedClass2 {
    pub fn new(inner: Class2, tracker: Option<TestTracker>) -> Self {
        InstrumentedClass2 { inner, tracker }
    }
}

impl Class2Trait for InstrumentedClass2 {
    fn transform(&mut self, x: i32) -> i32 {
        if let Some(tracker) = self.tracker.as_mut() {
            tracker.push_call("Enter Class2::transform");
            if tracker.inject_fault("Class2::transform") {
                println!("Triggering fault injection for Class2::transform");
                tracker.push_call("FAULT INJECTED");
                panic!("Fault injected in Class2::transform");
            }
            tracker.insert_value("Class2::transform_input", x);
            let result = self.inner.transform(x);
            tracker.push_call("Exit Class2::transform");
            tracker.insert_value("Class2::transform_output", result);
            result
        } else {
            self.inner.transform(x)
        }
    }

    fn combine(&mut self, x: i32, label: &str) -> String {
        if let Some(tracker) = self.tracker.as_mut() {
            tracker.push_call("Enter Class2::combine");
            if tracker.inject_fault("Class2::combine") {
                println!("Triggering fault injection for Class2::combine");
                tracker.push_call("FAULT INJECTED");
                panic!("Fault injected in Class2::combine");
            }
            tracker.insert_value("Class2::combine_input", x);
            let result = self.inner.combine(x, label);
            tracker.push_call("Exit Class2::combine");
            tracker.insert_value("Class2::combine_output", &result);
            result
        } else {
            self.inner.combine(x, label)
        }
    }

    fn get_name(&mut self) -> String {
        if let Some(tracker) = self.tracker.as_mut() {
            tracker.push_call("Enter Class2::get_name");
            if tracker.inject_fault("Class2::get_name") {
                println!("Triggering fault injection for Class2::get_name");
                tracker.push_call("FAULT INJECTED");
                panic!("Fault injected in Class2::get_name");
            }
            let result = self.inner.get_name();
            tracker.push_call("Exit Class2::get_name");
            tracker.insert_value("Class2::get_name_output", &result);
            result
        } else {
            self.inner.get_name()
        }
    }
}

impl fmt::Debug for InstrumentedClass2 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("InstrumentedClass2")
            .field("inner", &self.inner)
            .field("tracker", &self.tracker)
            .finish()
    }
}

pub struct TestClass2 {
    c2: Class2,
    ic2: InstrumentedClass2,
}

impl TestClass2 {
    pub fn new(c2: Class2, ic2: InstrumentedClass2) -> Self {
        TestClass2 { c2, ic2 }
    }

    pub fn transform(&mut self, x: i32) -> i32 {
        self.c2.transform(x)
    }

    pub fn proxy_transform(&mut self, x: i32) -> i32 {
        self.ic2.transform(x)
    }

    pub fn combine(&mut self, x: i32, label: &str) -> String {
        self.c2.combine(x, label)
    }

    pub fn proxy_combine(&mut self, x: i32, label: &str) -> String {
        self.ic2.combine(x, label)
    }

    pub fn get_name(&mut self) -> String {
        self.c2.get_name()
    }

    pub fn proxy_get_name(&mut self) -> String {
        self.ic2.get_name()
    }
}