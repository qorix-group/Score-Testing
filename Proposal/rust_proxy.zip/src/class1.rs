use crate::class2::{Class2, Class2Trait};
use crate::class3::{Class3, Class3Trait};
use std::fmt;

#[derive(Clone)]
pub struct Class1 {
    c2: Class2,
    factor: i32,
    counter: i32,
}

pub trait Class1Trait: fmt::Debug {
    fn execute(&mut self, x: i32) -> i32;
    fn compute(&mut self, value: f64, count: i32) -> f64;
    fn get_counter(&self) -> i32;
}

impl Class1 {
    pub fn new() -> Self {
        Class1 {
            c2: Class2::new(),
            factor: 3,
            counter: 0,
        }
    }
}

impl Class1Trait for Class1 {
    fn execute(&mut self, x: i32) -> i32 {
        self.counter += 1;
        self.c2.transform(x) * self.factor // Step 1: ((x*2 + offset) * multiplier) * factor
    }

    fn compute(&mut self, value: f64, count: i32) -> f64 {
        let mut c3 = Class3::new();
        self.counter += 1;
        c3.scale(value, count) * self.c2.get_name().len() as f64 // Combines results and attribute
    }

    fn get_counter(&self) -> i32 {
        self.counter
    }
}

impl fmt::Debug for Class1 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Class1")
            .field("c2", &self.c2)
            .field("factor", &self.factor)
            .field("counter", &self.counter)
            .finish()
    }
}