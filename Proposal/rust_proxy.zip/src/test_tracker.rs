use std::collections::HashMap;

#[derive(Clone, Default, Debug)]
pub struct TestTracker {
    pub call_stack: Vec<String>,
    pub values: HashMap<String, String>,
    inject_fault: Option<String>,
}

impl TestTracker {
    pub fn reset(&mut self) {
        self.call_stack.clear();
        self.values.clear();
        self.inject_fault = None;
    }

    pub fn push_call(&mut self, call: &str) {
        self.call_stack.push(call.to_string());
    }

    pub fn insert_value<T: ToString>(&mut self, key: &str, value: T) {
        self.values.insert(key.to_string(), value.to_string());
    }

    pub fn set_inject_fault(&mut self, target: &str) {
        self.inject_fault = Some(target.to_string());
    }

    pub fn inject_fault(&self, target: &str) -> bool {
        self.inject_fault.as_deref() == Some(target)
    }
}