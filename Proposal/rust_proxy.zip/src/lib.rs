pub mod class1;
pub mod class2;
pub mod class3;
pub mod test_tracker;
pub mod test_class1;
pub mod test_class2;
pub mod test_class3;

#[cfg(test)]
mod tests {
    use super::test_tracker::TestTracker;
    use super::*;
    use rstest::{rstest, fixture};
    use std::i32;

    #[fixture]
    fn tracker() -> TestTracker {
        TestTracker::default()
    }

    #[rstest]
    fn unit_execute_positive(tracker: TestTracker) {
        let c1 = class1::Class1::new();
        let mut tc1 = test_class1::TestClass1::new(
            c1.clone(),
            test_class1::InstrumentedClass1::new(c1.clone(), Some(tracker.clone())),
        );
        let result = tc1.execute(2);
        assert_eq!(result, ((2 * 2 + 5) * 2) * 3); // (2*2+5=9)*2=18*3=54
        assert_eq!(tc1.get_counter(), 1);
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_execute_negative(tracker: TestTracker) {
        let c1 = class1::Class1::new();
        let mut tc1 = test_class1::TestClass1::new(
            c1.clone(),
            test_class1::InstrumentedClass1::new(c1.clone(), Some(tracker.clone())),
        );
        let result = tc1.execute(-2);
        assert_eq!(result, ((-2 * 2 + 5) * 2) * 3); // (-2*2+5=1)*2=2*3=6
        assert_eq!(tc1.get_counter(), 1);
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_execute_zero(tracker: TestTracker) {
        let c1 = class1::Class1::new();
        let mut tc1 = test_class1::TestClass1::new(
            c1.clone(),
            test_class1::InstrumentedClass1::new(c1.clone(), Some(tracker.clone())),
        );
        let result = tc1.execute(0);
        assert_eq!(result, ((0 * 2 + 5) * 2) * 3); // (0*2+5=5)*2=10*3=30
        assert_eq!(tc1.get_counter(), 1);
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_execute_max(tracker: TestTracker) {
        let c1 = class1::Class1::new();
        let mut tc1 = test_class1::TestClass1::new(
            c1.clone(),
            test_class1::InstrumentedClass1::new(c1.clone(), Some(tracker.clone())),
        );
        let result = tc1.execute(i32::MAX);
        assert_eq!(
            result,
            (((i32::MAX as i64 * 2 + 5) * 2) as i64 * 3) as i32
        ); // Overflow erwartet, modulo 2^32
        assert_eq!(tc1.get_counter(), 1);
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_fault_injection_execute_typical(mut tracker: TestTracker) {
        let c1 = class1::Class1::new();
        tracker.set_inject_fault("Class1::execute");
        let mut tc1 = test_class1::TestClass1::new(
            c1.clone(),
            test_class1::InstrumentedClass1::new(c1.clone(), Some(tracker.clone())),
        );
        assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| tc1.proxy_execute(2))).is_err());
        assert_eq!(tc1.get_counter(), 0);
    }

    #[rstest]
    fn unit_compute_positive(tracker: TestTracker) {
        let c1 = class1::Class1::new();
        let mut tc1 = test_class1::TestClass1::new(
            c1.clone(),
            test_class1::InstrumentedClass1::new(c1.clone(), Some(tracker.clone())),
        );
        let result = tc1.compute(2.5, 3);
        assert_eq!(result, (2.5 * 3.0 + 5.0) * 6.0); // (2.5*3+5=12.5)*6=75
        assert_eq!(tc1.get_counter(), 1);
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_compute_negative(tracker: TestTracker) {
        let c1 = class1::Class1::new();
        let mut tc1 = test_class1::TestClass1::new(
            c1.clone(),
            test_class1::InstrumentedClass1::new(c1.clone(), Some(tracker.clone())),
        );
        let result = tc1.compute(-2.5, -3);
        assert_eq!(result, (-2.5 * -3.0 + 5.0) * 6.0); // (-2.5*-3+5=12.5)*6=75
        assert_eq!(tc1.get_counter(), 1);
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_compute_zero(tracker: TestTracker) {
        let c1 = class1::Class1::new();
        let mut tc1 = test_class1::TestClass1::new(
            c1.clone(),
            test_class1::InstrumentedClass1::new(c1.clone(), Some(tracker.clone())),
        );
        let result = tc1.compute(0.0, 0);
        assert_eq!(result, (0.0 * 0.0 + 5.0) * 6.0); // (0*0+5=5)*6=30
        assert_eq!(tc1.get_counter(), 1);
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_compute_max_value(tracker: TestTracker) {
        let c1 = class1::Class1::new();
        let mut tc1 = test_class1::TestClass1::new(
            c1.clone(),
            test_class1::InstrumentedClass1::new(c1.clone(), Some(tracker.clone())),
        );
        let result = tc1.compute(f64::MAX, 1);
        assert_eq!(result, (f64::MAX * 1.0 + 5.0) * 6.0);
        assert_eq!(tc1.get_counter(), 1);
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_compute_negative_count(tracker: TestTracker) {
        let c1 = class1::Class1::new();
        let mut tc1 = test_class1::TestClass1::new(
            c1.clone(),
            test_class1::InstrumentedClass1::new(c1.clone(), Some(tracker.clone())),
        );
        let result = tc1.compute(2.5, -3);
        assert_eq!(result, (2.5 * -3.0 + 5.0) * 6.0); // (2.5*-3+5=-2.5)*6=-15
        assert_eq!(tc1.get_counter(), 1);
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_fault_injection_compute_typical(mut tracker: TestTracker) {
        let c1 = class1::Class1::new();
        tracker.set_inject_fault("Class1::compute");
        let mut tc1 = test_class1::TestClass1::new(
            c1.clone(),
            test_class1::InstrumentedClass1::new(c1.clone(), Some(tracker.clone())),
        );
        assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| tc1.proxy_compute(2.5, 3))).is_err());
        assert_eq!(tc1.get_counter(), 0);
    }

    #[rstest]
    fn unit_get_counter_non_zero(tracker: TestTracker) {
        let c1 = class1::Class1::new();
        let mut tc1 = test_class1::TestClass1::new(
            c1.clone(),
            test_class1::InstrumentedClass1::new(c1.clone(), Some(tracker.clone())),
        );
        tc1.execute(2);
        let result = tc1.get_counter();
        assert_eq!(result, 1);
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_get_counter_zero(tracker: TestTracker) {
        let c1 = class1::Class1::new();
        let tc1 = test_class1::TestClass1::new(
            c1.clone(),
            test_class1::InstrumentedClass1::new(c1.clone(), Some(tracker.clone())),
        );
        let result = tc1.get_counter();
        assert_eq!(result, 0);
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_fault_injection_get_counter(mut tracker: TestTracker) {
        let c1 = class1::Class1::new();
        tracker.set_inject_fault("Class1::get_counter");
        let mut tc1 = test_class1::TestClass1::new(
            c1.clone(),
            test_class1::InstrumentedClass1::new(c1.clone(), Some(tracker.clone())),
        );
        tc1.execute(2);
        assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| tc1.proxy_get_counter())).is_err());
    }

    #[rstest]
    fn unit_transform_positive(tracker: TestTracker) {
        let c2 = class2::Class2::new();
        let mut tc2 = test_class2::TestClass2::new(
            c2.clone(),
            test_class2::InstrumentedClass2::new(c2.clone(), Some(tracker.clone())),
        );
        let result = tc2.transform(2);
        assert_eq!(result, (2 * 2 + 5) * 2); // (2*2+5=9)*2=18
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_transform_negative(tracker: TestTracker) {
        let c2 = class2::Class2::new();
        let mut tc2 = test_class2::TestClass2::new(
            c2.clone(),
            test_class2::InstrumentedClass2::new(c2.clone(), Some(tracker.clone())),
        );
        let result = tc2.transform(-2);
        assert_eq!(result, (-2 * 2 + 5) * 2); // (-2*2+5=1)*2=2
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_transform_zero(tracker: TestTracker) {
        let c2 = class2::Class2::new();
        let mut tc2 = test_class2::TestClass2::new(
            c2.clone(),
            test_class2::InstrumentedClass2::new(c2.clone(), Some(tracker.clone())),
        );
        let result = tc2.transform(0);
        assert_eq!(result, (0 * 2 + 5) * 2); // (0*2+5=5)*2=10
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_transform_max(tracker: TestTracker) {
        let c2 = class2::Class2::new();
        let mut tc2 = test_class2::TestClass2::new(
            c2.clone(),
            test_class2::InstrumentedClass2::new(c2.clone(), Some(tracker.clone())),
        );
        let result = tc2.transform(i32::MAX);
        assert_eq!(result, ((i32::MAX as i64 * 2 + 5) * 2) as i32); // Overflow erwartet, modulo 2^32
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_fault_injection_transform_typical(mut tracker: TestTracker) {
        let c2 = class2::Class2::new();
        tracker.set_inject_fault("Class2::transform");
        let mut tc2 = test_class2::TestClass2::new(
            c2.clone(),
            test_class2::InstrumentedClass2::new(c2.clone(), Some(tracker.clone())),
        );
        assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| tc2.proxy_transform(2))).is_err());
    }

    #[rstest]
    fn unit_combine_positive(tracker: TestTracker) {
        let c2 = class2::Class2::new();
        let mut tc2 = test_class2::TestClass2::new(
            c2.clone(),
            test_class2::InstrumentedClass2::new(c2.clone(), Some(tracker.clone())),
        );
        let result = tc2.combine(10, "TestLabel");
        assert_eq!(result, "Class3: Processing unit | TestLabel | 10");
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_combine_zero(tracker: TestTracker) {
        let c2 = class2::Class2::new();
        let mut tc2 = test_class2::TestClass2::new(
            c2.clone(),
            test_class2::InstrumentedClass2::new(c2.clone(), Some(tracker.clone())),
        );
        let result = tc2.combine(0, "TestLabel");
        assert_eq!(result, "Class3: Processing unit | TestLabel | 0");
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_combine_empty_label(tracker: TestTracker) {
        let c2 = class2::Class2::new();
        let mut tc2 = test_class2::TestClass2::new(
            c2.clone(),
            test_class2::InstrumentedClass2::new(c2.clone(), Some(tracker.clone())),
        );
        let result = tc2.combine(10, "");
        assert_eq!(result, "Class3: Processing unit |  | 10");
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_combine_long_label(tracker: TestTracker) {
        let c2 = class2::Class2::new();
        let mut tc2 = test_class2::TestClass2::new(
            c2.clone(),
            test_class2::InstrumentedClass2::new(c2.clone(), Some(tracker.clone())),
        );
        let long_label = "A".repeat(1000);
        let result = tc2.combine(10, &long_label);
        assert_eq!(result, format!("Class3: Processing unit | {} | 10", long_label));
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_fault_injection_combine_typical(mut tracker: TestTracker) {
        let c2 = class2::Class2::new();
        tracker.set_inject_fault("Class2::combine");
        let mut tc2 = test_class2::TestClass2::new(
            c2.clone(),
            test_class2::InstrumentedClass2::new(c2.clone(), Some(tracker.clone())),
        );
        assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| tc2.proxy_combine(10, "TestLabel"))).is_err());
    }

    #[rstest]
    fn unit_get_name_default(tracker: TestTracker) {
        let c2 = class2::Class2::new();
        let mut tc2 = test_class2::TestClass2::new(
            c2.clone(),
            test_class2::InstrumentedClass2::new(c2.clone(), Some(tracker.clone())),
        );
        let result = tc2.get_name();
        assert_eq!(result, "Class2");
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_fault_injection_get_name(mut tracker: TestTracker) {
        let c2 = class2::Class2::new();
        tracker.set_inject_fault("Class2::get_name");
        let mut tc2 = test_class2::TestClass2::new(
            c2.clone(),
            test_class2::InstrumentedClass2::new(c2.clone(), Some(tracker.clone())),
        );
        assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| tc2.proxy_get_name())).is_err());
    }

    #[rstest]
    fn unit_process_positive(tracker: TestTracker) {
        let c3 = class3::Class3::new();
        let mut tc3 = test_class3::TestClass3::new(
            c3.clone(),
            test_class3::InstrumentedClass3::new(c3.clone(), Some(tracker.clone())),
        );
        let result = tc3.process(2);
        assert_eq!(result, 2 * 2 + 5); // 2*2+5=9
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_process_negative(tracker: TestTracker) {
        let c3 = class3::Class3::new();
        let mut tc3 = test_class3::TestClass3::new(
            c3.clone(),
            test_class3::InstrumentedClass3::new(c3.clone(), Some(tracker.clone())),
        );
        let result = tc3.process(-2);
        assert_eq!(result, -2 * 2 + 5); // -2*2+5=1
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_process_zero(tracker: TestTracker) {
        let c3 = class3::Class3::new();
        let mut tc3 = test_class3::TestClass3::new(
            c3.clone(),
            test_class3::InstrumentedClass3::new(c3.clone(), Some(tracker.clone())),
        );
        let result = tc3.process(0);
        assert_eq!(result, 0 * 2 + 5); // 0*2+5=5
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_process_max(tracker: TestTracker) {
        let c3 = class3::Class3::new();
        let mut tc3 = test_class3::TestClass3::new(
            c3.clone(),
            test_class3::InstrumentedClass3::new(c3.clone(), Some(tracker.clone())),
        );
        let result = tc3.process(i32::MAX);
        assert_eq!(result, (i32::MAX as i64 * 2 + 5) as i32); // Overflow erwartet, modulo 2^32
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_fault_injection_process_typical(mut tracker: TestTracker) {
        let c3 = class3::Class3::new();
        tracker.set_inject_fault("Class3::process");
        let mut tc3 = test_class3::TestClass3::new(
            c3.clone(),
            test_class3::InstrumentedClass3::new(c3.clone(), Some(tracker.clone())),
        );
        assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| tc3.proxy_process(2))).is_err());
    }

    #[rstest]
    fn unit_scale_positive(tracker: TestTracker) {
        let c3 = class3::Class3::new();
        let mut tc3 = test_class3::TestClass3::new(
            c3.clone(),
            test_class3::InstrumentedClass3::new(c3.clone(), Some(tracker.clone())),
        );
        let result = tc3.scale(2.5, 3);
        assert_eq!(result, 2.5 * 3.0 + 5.0); // 2.5*3+5=12.5
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_scale_negative(tracker: TestTracker) {
        let c3 = class3::Class3::new();
        let mut tc3 = test_class3::TestClass3::new(
            c3.clone(),
            test_class3::InstrumentedClass3::new(c3.clone(), Some(tracker.clone())),
        );
        let result = tc3.scale(-2.5, -3);
        assert_eq!(result, -2.5 * -3.0 + 5.0); // -2.5*-3+5=12.5
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_scale_zero(tracker: TestTracker) {
        let c3 = class3::Class3::new();
        let mut tc3 = test_class3::TestClass3::new(
            c3.clone(),
            test_class3::InstrumentedClass3::new(c3.clone(), Some(tracker.clone())),
        );
        let result = tc3.scale(0.0, 0);
        assert_eq!(result, 0.0 * 0.0 + 5.0); // 0*0+5=5
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_scale_max_factor(tracker: TestTracker) {
        let c3 = class3::Class3::new();
        let mut tc3 = test_class3::TestClass3::new(
            c3.clone(),
            test_class3::InstrumentedClass3::new(c3.clone(), Some(tracker.clone())),
        );
        let result = tc3.scale(f64::MAX, 1);
        assert_eq!(result, f64::MAX * 1.0 + 5.0);
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_scale_negative_count(tracker: TestTracker) {
        let c3 = class3::Class3::new();
        let mut tc3 = test_class3::TestClass3::new(
            c3.clone(),
            test_class3::InstrumentedClass3::new(c3.clone(), Some(tracker.clone())),
        );
        let result = tc3.scale(2.5, -3);
        assert_eq!(result, 2.5 * -3.0 + 5.0); // 2.5*-3+5=-2.5
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_fault_injection_scale_typical(mut tracker: TestTracker) {
        let c3 = class3::Class3::new();
        tracker.set_inject_fault("Class3::scale");
        let mut tc3 = test_class3::TestClass3::new(
            c3.clone(),
            test_class3::InstrumentedClass3::new(c3.clone(), Some(tracker.clone())),
        );
        assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| tc3.proxy_scale(2.5, 3))).is_err());
    }

    #[rstest]
    fn unit_describe_default(tracker: TestTracker) {
        let c3 = class3::Class3::new();
        let mut tc3 = test_class3::TestClass3::new(
            c3.clone(),
            test_class3::InstrumentedClass3::new(c3.clone(), Some(tracker.clone())),
        );
        let result = tc3.describe();
        assert_eq!(result, "Class3: Processing unit");
        assert!(tracker.call_stack.is_empty());
    }

    #[rstest]
    fn unit_fault_injection_describe(mut tracker: TestTracker) {
        let c3 = class3::Class3::new();
        tracker.set_inject_fault("Class3::describe");
        let mut tc3 = test_class3::TestClass3::new(
            c3.clone(),
            test_class3::InstrumentedClass3::new(c3.clone(), Some(tracker.clone())),
        );
        assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| tc3.proxy_describe())).is_err());
    }
}